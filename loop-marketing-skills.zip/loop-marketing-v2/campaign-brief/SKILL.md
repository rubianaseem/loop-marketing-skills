---
name: campaign-brief
description: >
  Builds a complete, structured B2B campaign brief from scratch — the strategic document
  that aligns stakeholders before a campaign begins. ALWAYS trigger when a marketer needs
  to brief an agency, align a team, document a campaign plan, start a new campaign, or
  needs a structured brief template. Also trigger for: "write a campaign brief", "brief
  this campaign", "campaign one-pager", "brief template", "campaign document", "align the
  team on this campaign", or "before we start the campaign what do we need to agree on."
  Use this skill to capture strategy and create alignment before execution begins.
---

# Campaign Brief

## What This Skill Does

Produces a complete, shareable campaign brief that aligns everyone — marketing team,
agency, sales, and leadership — before a single piece of content is created. The brief
is the contract between strategy and execution.

---

## When To Use This Skill

- Starting a new campaign and need to document the plan
- Briefing an agency or freelancer
- Aligning marketing and sales before a campaign launches
- Creating a reusable brief template for your team
- Turning Loop Marketing Express output into an executable document

---

## Input Required

Ask for these if not provided:

1. **Campaign name/topic** — what is this campaign about?
2. **Business goal** — what commercial outcome does it need to drive?
3. **Target audience** — ICP, personas, lifecycle stage
4. **Core message** — the one thing the audience should understand
5. **Channels** — where will this campaign run?
6. **Timeline** — start date, key milestones, end date
7. **Budget** — total budget and allocation
8. **Success metrics** — how will you know it worked?

---

## Brief Structure

Produce the campaign brief in this format:

```
# Campaign Brief: [Campaign Name]

**Date:** [Date]
**Owner:** [Name/Team]
**Status:** Draft / Approved

---

## 1. Campaign Summary
[2-3 sentences. What is this campaign, why now, and what does it need to achieve?]

## 2. Business Objective
[The commercial outcome: pipeline, revenue, leads, retention. Include a specific number.]

## 3. Target Audience
**Primary:** [Job title + company size + industry + pain trigger]
**Secondary:** [If applicable]
**Lifecycle Stage:** [Awareness / Consideration / Decision / Retention]

## 4. Core Message
[The one sentence the audience must walk away understanding. Not a tagline.]

## 5. Supporting Messages
1. [For Persona A / Benefit 1]
2. [For Persona B / Benefit 2]
3. [Proof point / objection handle]

## 6. Campaign Concept
**Name:** [Campaign name or working title]
**Big Idea:** [The creative hook in 1-2 sentences]
**Tone:** [3 adjectives describing the voice]

## 7. Channel Plan
| Channel | Format | Frequency | Owner |
|---------|--------|-----------|-------|
| [Channel] | [Format] | [Frequency] | [Owner] |

## 8. Hero Content
[The anchor content piece everything else derives from. Title + format + brief description.]

## 9. Timeline
| Milestone | Date | Owner |
|-----------|------|-------|
| Brief approved | [Date] | [Owner] |
| Content created | [Date] | [Owner] |
| Campaign live | [Date] | [Owner] |
| Review point | [Date] | [Owner] |

## 10. Budget
**Total:** [Amount]
**Allocation:**
- Content production: [Amount / %]
- Paid distribution: [Amount / %]
- Tools/platform: [Amount / %]

## 11. KPIs & Success Metrics
| Metric | Baseline | Target | Measurement Tool |
|--------|----------|--------|-----------------|
| [Metric] | [Current] | [Goal] | [Tool] |

## 12. Dependencies & Approvals
**Requires:** [Legal review / Product input / Sales alignment / etc.]
**Approved by:** [Name + date]

## 13. Notes
[Any additional context, constraints, or considerations]
```

---

## Key Principles

- **Brief before brief** — a bad brief produces a good execution of the wrong campaign
- **One goal per campaign** — multiple objectives dilute everything
- **The brief is a contract** — changes after approval need a documented reason
- **Sales must see it** — campaigns that sales haven't bought into won't convert pipeline
