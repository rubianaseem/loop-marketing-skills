---
name: content-remix
description: >
  Atomises one piece of hero content into multiple formats and channels — turning a single
  asset into a full content programme. ALWAYS trigger when a marketer wants to repurpose
  content, get more from one piece of content, turn a webinar into posts, atomise a blog,
  repurpose a case study, remix a report, or build a content calendar from one idea.
  Also trigger for: "repurpose this", "atomise this content", "get more from this blog/webinar/
  report", "turn this into LinkedIn posts", "content calendar from this", "how many pieces
  can I get from this?", or "remix this content." The goal is maximum reach from minimum
  production effort.
---

# Content Remix

## What This Skill Does

Takes ONE piece of hero content and systematically produces every derivative format it can
become — so B2B marketers get 30 days of content from a single asset, not one post and done.

---

## When To Use This Skill

- After a webinar, podcast episode, or live event
- After publishing a long-form report, guide, or white paper
- After a client case study is approved
- When a blog post isn't getting enough reach
- When you need a content calendar but only have one asset
- When content production bandwidth is limited

---

## Input Required

1. **The hero content** — paste the full text, transcript, or detailed summary
2. **Target audience** — who are you trying to reach with the remixes?
3. **Primary channel** — where does most of your audience live?
4. **Campaign goal** — awareness, lead gen, nurture, or retention?

---

## The Remix Engine

Analyse the hero content and produce outputs in this order:

### Tier 1 — LinkedIn Content (Highest B2B priority)
1. **Long-form insight post** — 800-1200 words, storytelling format, 1 key insight
2. **Carousel concept** — 8-10 slides, title + 7 insight slides + CTA slide (write headlines for each)
3. **Short punchy post** — under 150 words, contrarian take or strong statistic
4. **Poll post** — question derived from a key debate in the content
5. **Story post** — personal experience angle on the same insight

### Tier 2 — Email Content
6. **Newsletter section** — 200-300 words, one insight, one link
7. **Email hook** — 3 subject line options + preview text for sending to a list
8. **Nurture email** — 400-500 words, educate + soft CTA for mid-funnel contacts

### Tier 3 — Short Video
9. **Talking head script** — 60-90 second video script, hook + 3 points + CTA
10. **LinkedIn video hook** — first 3 seconds script (the moment that stops the scroll)

### Tier 4 — Community & Conversation
11. **LinkedIn comment bait** — a post designed to generate comments and debate
12. **Community post** — for Slack/Discord communities, discussion starter format
13. **Podcast talking points** — 5 bullet points if pitching to appear on a podcast

### Tier 5 — Long-Form Derivatives
14. **Blog post outline** — title, H2 headings, key point per section, conclusion
15. **FAQ document** — 5 questions the content answers, in Q&A format
16. **Slide deck outline** — for a presentation or sales conversation starter

---

## Output Format

```
# Content Remix: [Original Content Title]
**Source:** [Content type + date]
**Target audience:** [ICP]
**Campaign goal:** [Goal]

---

## Tier 1 — LinkedIn (5 pieces)
[Write each one in full or provide detailed brief for each]

## Tier 2 — Email (3 pieces)
[Write or brief each]

## Tier 3 — Video (2 scripts)
[Write scripts in full]

## Tier 4 — Community (3 pieces)
[Write each]

## Tier 5 — Long-Form Derivatives (3 outlines)
[Outline each]

---

## 30-Day Posting Schedule
[Map the 16 pieces across 4 weeks, recommended channels and days]
```

---

## Key Principles

- **One insight per piece** — don't try to say everything in every format
- **Reframe, don't repost** — each derivative should feel native to its channel
- **Lead with the best** — strongest insight first, not chronological order
- **The hero piece earns the derivatives** — quality anchor content is non-negotiable
