---
name: copywriting
description: >
  Writes high-converting B2B marketing copy for any format — landing pages, ads, email copy,
  case studies, website copy, value propositions, CTAs, and campaign headlines. ALWAYS trigger
  when a marketer needs to write or improve actual copy — not strategy, but the words themselves.
  Trigger for: "write copy for", "write this landing page", "improve my headline", "rewrite this",
  "write my value proposition", "ad copy", "website copy", "case study copy", "write the CTA",
  "make this copy better", or any request to produce actual marketing words. This skill applies
  B2B copywriting frameworks to produce copy that converts, not just sounds good.
---

# Copywriting

## What This Skill Does

Writes and improves B2B marketing copy using proven frameworks — so every word earns its place.
Not fluffy content. Not AI-flavoured filler. Specific, direct, audience-aware copy that converts.

---

## When To Use This Skill

- Writing landing page copy from scratch
- Improving existing copy that isn't converting
- Writing ad copy for LinkedIn, Google, or retargeting
- Turning a case study into a compelling story
- Writing value propositions and positioning statements
- Improving website homepage or about page copy
- Writing CTAs that actually get clicked

---

## Input Required

1. **What to write** — landing page, email, ad, headline, value prop, CTA, case study?
2. **Target audience** — ICP, job title, pain point
3. **The goal** — what action should the reader take?
4. **Brand voice** — tone adjectives, things they'd never say
5. **Existing draft** — if improving, paste what exists
6. **Key proof points** — data, results, testimonials available

---

## Copywriting Frameworks (Select Based On Format)

### For Headlines & Hooks
- **Problem → Agitate → Solution (PAS):** Name the pain → make it real → offer the fix
- **Before → After → Bridge:** Where they are → where they could be → how to get there
- **Specific Result + Timeframe + Objection Handle:** "42% more qualified leads in 90 days — without adding headcount"

### For Landing Pages
Structure: Hook → Problem → Stakes → Solution → Proof → CTA
- Hook: Stops the scroll — specific, relevant, contrarian or data-driven
- Problem: Names their reality in their language (voice of customer phrases)
- Stakes: What happens if this problem isn't solved?
- Solution: What you do and how it's different (features as benefits)
- Proof: Specific results, named clients, quantified outcomes
- CTA: One action, clear verb, low friction

### For Value Propositions
Formula: **We help [ICP] achieve [outcome] by [method] — without [common objection].**
Test: Does it pass "So what?", "Who cares?", "Prove it?"

### For Case Studies
Structure: Challenge → Stakes → Solution → Results → Quote
- Challenge: The specific problem the client had (in their words if possible)
- Stakes: What was at risk if unsolved — revenue, board pressure, team morale
- Solution: What was implemented and why — be specific about the approach
- Results: Quantified outcomes with timeframes ("42% increase in 90 days")
- Quote: Client quote that reinforces the outcome, not the relationship

### For Email Copy
Structure: Subject → Preview → Hook → Story/Insight → Payoff → CTA
- Subject line: Under 45 characters, specific, curiosity or relevance trigger
- Preview text: Extends the subject, adds context, doesn't repeat
- Hook: First sentence must earn the second
- CTA: One link. One ask. Specific action.

### For Ad Copy
- LinkedIn: Lead with the pain. Short. Direct. Strong CTA.
- Google: Match the search intent exactly. Feature the differentiator.
- Retargeting: Acknowledge they've been there. Reduce friction. Use social proof.

---

## Copy Quality Tests (Run Before Delivering)

1. **The "so what?" test** — does every claim matter to the reader?
2. **The "who are you talking to?" test** — would a stranger know exactly who this is for?
3. **The "what do I do next?" test** — is the CTA clear and frictionless?
4. **The "could a competitor say this?" test** — if yes, it's not differentiated enough
5. **The "customer language" test** — are you using their words or your internal jargon?

---

## Output Format

Always deliver:
1. **Primary copy** — the full piece in the requested format
2. **Headline alternatives** — 3 variations with different angles
3. **CTA alternatives** — 3 options with different friction levels
4. **Brief rationale** — 2-3 sentences explaining the strategic choices made

---

## Key Principles

- **Specific beats clever** — "42% more leads" beats "transform your marketing"
- **One idea per piece** — dilution kills conversion
- **Earn every sentence** — if a sentence doesn't advance the argument, cut it
- **Write for the skim** — subheadings, short paragraphs, bold the key point
- **Benefits over features** — always answer "so what does that mean for me?"
