---
name: loop-marketing
description: >
  The master orchestrator for HubSpot's Loop Marketing framework. Chains all 4 stages
  (Express → Tailor → Amplify → Evolve) automatically into one complete campaign system.
  ALWAYS trigger this skill when a marketer wants to build a full campaign, take an idea
  through the loop, create a marketing strategy, launch a product, or turn one insight into
  multi-channel content. Also trigger when the user says "loop marketing", "full campaign",
  "marketing plan", "campaign strategy", or "take this through the loop." This is the
  starting point for any end-to-end B2B marketing campaign request.
---

# Loop Marketing — Master Orchestrator

## What This Skill Does

Takes **one B2B marketing idea, brief, or insight** and chains all 4 Loop Marketing stages
automatically — producing a complete, compounding campaign system from a single input.

**The Loop:** Express → Tailor → Amplify → Evolve

Each stage feeds the next. Each loop feeds the next loop. This is how compound growth happens.

---

## Input — Collect Before Starting

Ask the marketer for (if not already provided):

1. **The idea or topic** — campaign brief, product feature, client win, industry insight, or trending topic
2. **Company/brand context** — what they do, who they serve, CRM platform (HubSpot/Salesforce)
3. **Primary goal** — awareness, lead generation, pipeline, nurture, or retention
4. **Target audience** — job titles, company size, industry vertical
5. **Optional: Preferred channels** — LinkedIn, email, paid, community, events

If fewer than 3 of these are provided, ask for the missing details before proceeding.

---

## Stage Execution — Run In Sequence

### 🟡 Stage 1 — EXPRESS
📖 Read `references/01-express.md` before executing.
Fires internally: Brand Differentiation Analyzer, Ideal Customer Profiler, Campaign Concept Generator, and 22 supporting Express prompts.
**Output:** Brand POV, ICP snapshot, campaign concept, style guide.

### 🔵 Stage 2 — TAILOR
📖 Read `references/02-tailor.md` before executing.
Fires internally: Hyper-Personalization Engine, Behavioral Segmentation Builder, Lifecycle Mapper, and 22 supporting Tailor prompts.
**Output:** 2-3 audience segments with personalised messaging, CRM trigger logic.

### 🟣 Stage 3 — AMPLIFY
📖 Read `references/03-amplify.md` before executing.
Fires internally: Channel Diversification Strategist, AI Search Visibility Optimizer, Content Amplification Engine, and 22 supporting Amplify prompts.
**Output:** Multi-channel distribution plan, 30-day content calendar, AEO strategy.

### 🟢 Stage 4 — EVOLVE
📖 Read `references/04-evolve.md` before executing.
Fires internally: Campaign Performance Diagnostician, Systematic Testing Framework, Multi-Loop Learning Synthesizer, and 22 supporting Evolve prompts.
**Output:** KPIs, A/B experiments, feed-forward insight for next loop.

---

## Output Format

```
# Loop Marketing Plan: [Campaign Name]

## 🎯 Campaign Foundation
[ICP, goal, core message — 3-4 sentences]

## Stage 1 — EXPRESS: Brand & POV
[Brand angle, differentiation, campaign concept, style guide snapshot]

## Stage 2 — TAILOR: Audience Segments
[2-3 segments with personalised hooks, CRM triggers]

## Stage 3 — AMPLIFY: Channel Plan
[Channel mix, content formats, 30-day calendar, AEO]

## Stage 4 — EVOLVE: Metrics & Experiments
[KPIs per stage, 3 A/B tests to run, loop velocity target]

## 🔁 Loop Feed-Forward
[What this loop teaches — feeds directly into Loop 2]
```

---

## Execution Modes

**Quick Loop** — User says "quick loop" or "give me the plan fast"
→ Condensed one-page output, bullet points per stage, skip deep copy

**Full Loop** — User says "full loop", "go deep", or "complete campaign"
→ Read all 4 reference files, produce full output with copy examples and 30-day calendar

**Single Stage** — User says "just the Express stage" or "only tailor this"
→ Run only the requested stage, reference that stage's file only

---

## Key Principles

- **Human authenticity first** — AI accelerates, but brand voice must be real and distinct
- **One idea, many formats** — every insight remixed across channels
- **Loops compound** — each cycle explicitly feeds the next
- **Measure velocity** — experiments per month matters as much as conversion rate
- **AEO matters** — optimise for ChatGPT, Claude, and Perplexity, not just Google
- **CRM is the spine** — every stage connects back to HubSpot or Salesforce data
