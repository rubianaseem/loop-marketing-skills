# Stage 3 — AMPLIFY Reference

## What Amplify Does
Distribute your campaign across every channel your audience actually uses — including AI search
engines (AEO). Turn one campaign concept into a multi-format content engine that creates
compounding reach without proportional effort.

---

## The 25 Amplify Prompts (Embedded Engine)

### Channel Strategy

**1. Channel Diversification Strategist**
Role: You are a Multi-Channel Marketing Strategist.
Task: For [ICP], identify the top 5 channels ranked by: audience presence, content fit, and
competitive noise level. Build a channel mix that maximises reach while minimising duplication of effort.

**2. Community-Driven Distribution**
Role: You are a Community Marketing Manager.
Task: Identify [ICP]-specific communities (LinkedIn groups, Slack communities, industry forums,
subreddits, Discord servers). Build an organic distribution strategy that adds value, not spam.

**3. Creator Partnership Strategist**
Role: You are a B2B Influencer Marketing Manager.
Task: Identify 5 non-competing thought leaders or creators who reach [ICP]. Define the
co-creation angle, the mutual benefit, and the outreach approach.

**4. AI Search Visibility Optimizer**
Role: You are an AI Engine Optimisation (AEO) Specialist.
Task: Optimise [campaign content] for ChatGPT, Claude, and Perplexity. Define the questions
[ICP] asks AI tools. Write content that becomes the answer. Include: schema, citations, FAQ structure.

**5. Video Content Amplifier**
Role: You are a Video Marketing Strategist.
Task: Turn [campaign concept] into a video content plan. Include: long-form (YouTube/webinar),
short-form (LinkedIn/Reels), and micro-clips (15-30s). Define production complexity vs. impact.

**6. Strategic Partner Identifier**
Role: You are a Partner Marketing Manager.
Task: Identify 3 non-competing companies with access to [ICP]. Design a co-marketing campaign:
shared content, joint webinar, newsletter swap, or integrated campaign. Define mutual value clearly.

**7. Event Marketing Amplifier**
Role: You are an Event Marketing Strategist.
Task: Map [ICP's] event calendar — conferences, industry summits, online events they attend.
Build a presence strategy: speaking pitches, sponsorship ROI, content to create around each event.

### Content Production & Distribution

**8. Content Amplification Engine**
Role: You are a Content Distribution Specialist.
Task: Take [hero content piece] and atomise it into 10 derivative formats. Include: LinkedIn
posts, email sections, slide deck, short video script, podcast talking points, and newsletter edition.

**9. User-Generated Content Multiplier**
Role: You are a Community & UGC Strategist.
Task: Design a system that generates customer and community content for [company]. Include:
what to ask for, how to request it, how to repurpose it, and how to credit creators.

**10. Cross-Platform Content Strategy**
Role: You are a Social Media Strategist.
Task: Adapt [campaign message] for LinkedIn, X/Twitter, YouTube, and email with
platform-native formats, optimal length, and posting cadence for each.

**11. Paid Media Diversification**
Role: You are a Paid Media Strategist.
Task: Design a paid amplification strategy for [campaign] using: LinkedIn Ads, Google Ads,
and retargeting. Define audience targeting, budget split, ad formats, and KPIs per channel.

**12. Customer Advocacy Amplifier**
Role: You are a Customer Marketing Manager.
Task: Activate [company's] existing customers as distribution channels. Design a programme:
referral incentives, co-authoring, review generation, case study participation, and community championing.

**13. Podcast and Audio Strategy**
Role: You are a B2B Podcast Strategist.
Task: Build an audio distribution plan. Include: pitching as a guest on [ICP]-relevant podcasts,
creating a branded podcast series, and repurposing audio content from webinars and events.

**14. Event and Conference Amplifier**
Role: You are an Events Marketing Manager.
Task: Maximise content output from [event/conference]. Before, during, and after playbook:
pre-event anticipation, live coverage, post-event repurposing into 6-month content stream.

**15. Local and Regional Marketing Amplifier**
Role: You are a Regional Marketing Manager.
Task: For [company's] geographic focus, design localised amplification. Include: local
LinkedIn communities, regional media, country-specific events, and language considerations.

### Digital Distribution

**16. Cross-Channel Attribution Optimizer**
Role: You are a Marketing Analytics Specialist.
Task: Design the UTM and tracking structure for [campaign] across all channels. Ensure
every touchpoint is trackable in [CRM]. Define the attribution model and reporting dashboard.

**17. Content Distribution Network**
Role: You are a Content Syndication Specialist.
Task: Identify distribution networks for [content type]: syndication partners, newsletter
sponsorships, content aggregators, and media placements. Build a systematic outreach plan.

**18. Partnership Co-Marketing Engine**
Role: You are a Partner Marketing Strategist.
Task: Design a co-marketing programme with [partner]. Include: content responsibilities,
audience sharing, joint promotion schedule, shared UTMs, and success metrics.

**19. Industry Awards and Recognition Amplifier**
Role: You are a PR and Brand Strategist.
Task: Identify industry awards, lists, and recognition programmes [company] should apply for.
Define the application strategy and how to amplify wins across channels.

**20. Omnichannel Experience Orchestrator**
Role: You are an Omnichannel Marketing Architect.
Task: Map the contact's experience across all channels during [campaign]. Ensure message
consistency and progression — not repetition — as they move from LinkedIn to email to website.

### Events & Community

**21. Live Event and Webinar Amplifier**
Role: You are a Webinar Marketing Manager.
Task: Build a complete webinar campaign: pre-event promotion (3 weeks), day-of execution,
post-event content repurposing, and follow-up nurture sequence in [CRM].

**22. Thought Leadership Amplification**
Role: You are a Thought Leadership Strategist.
Task: Take [founder/leader's] expertise and amplify it systematically. Include: ghostwriting
support, LinkedIn strategy, speaking circuit, podcast appearances, and media pitching.

**23. Customer Referral Engine**
Role: You are a Growth Marketing Manager.
Task: Design a referral programme that turns customers into active distributors of [company's]
message. Include: trigger moment (when to ask), incentive structure, tracking in CRM, and activation email.

**24. Cross-Platform Viral Strategy**
Role: You are a Viral Marketing Strategist.
Task: Identify the conditions under which [campaign content] could achieve organic amplification.
Design the content hook, shareable format, and seeding strategy.

**25. Influencer Network Builder**
Role: You are a B2B Influencer Marketing Manager.
Task: Build a tiered influencer network for [company]: macro (50k+ followers), micro (5-50k),
and nano (under 5k but high-relevance). Define engagement approach and content collaboration model.

---

## Amplify Output Template

```
## 🟣 AMPLIFY — Stage 3 Output

**Primary Channels:** [Top 3 channels for this campaign + rationale]
**Hero Content Format:** [The anchor piece everything else derives from]

**30-Day Content Calendar:**
Week 1: [Content piece + channel + format]
Week 2: [Content piece + channel + format]
Week 3: [Content piece + channel + format]
Week 4: [Content piece + channel + format]

**Content Atomisation Plan:**
From [hero piece] → [5 derivative formats listed]

**AEO Strategy:**
- Questions to own in AI search: [3 specific questions]
- Content format: [FAQ/long-form/structured]
- Citation building: [Where to get featured]

**Paid Amplification:** [Channel + audience + budget guidance]
**Partnership Opportunity:** [One co-marketing play]
```
