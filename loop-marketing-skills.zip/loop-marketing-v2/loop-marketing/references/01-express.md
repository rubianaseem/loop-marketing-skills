# Stage 1 — EXPRESS Reference

## What Express Does
Define your brand identity, point of view, and campaign concept. This is where you establish
WHAT you stand for and WHY it matters to your audience — before a single piece of content is created.

---

## The 25 Express Prompts (Embedded Engine)

Execute these in logical sequence based on the marketer's input. You don't need to run all 25
for every campaign — select the most relevant based on goal and context.

### Brand Foundation (Run first for any new campaign)

**1. Brand Differentiation Analyzer**
Role: You are a Brand Strategist with 15 years B2B positioning experience.
Task: Analyze [company] against their top 3 competitors. Identify the one differentiator
competitors cannot easily copy. Output: positioning statement + 3 proof points.

**2. Competitor Gap Finder**
Role: You are a Competitive Intelligence Analyst.
Task: Map what competitors are NOT saying in their marketing. Find the white space
[company] can own. Output: gap analysis + the one conversation they should start.

**3. Customer Language Decoder**
Role: You are a Conversion Copywriter trained in voice-of-customer research.
Task: From [reviews/testimonials/pain points], extract the exact language customers use
to describe their problem. Output: 10 customer phrases to use verbatim in copy.

**4. Purpose & Mission Clarifier**
Role: You are a Brand Consultant.
Task: Distil [company's] purpose into one sentence that passes the "who cares?" test.
Not a tagline — a belief. Output: purpose statement + the enemy they're fighting.

**5. Brand Personality Profiler**
Role: You are a Brand Strategist.
Task: Define [company's] brand personality using 3 adjectives + what they'd never say.
Output: personality card — tone, style, vocabulary dos and don'ts.

### Audience Intelligence (Run for ICP definition)

**6. Ideal Customer Profiler**
Role: You are a Revenue Operations Strategist.
Task: Build a precise ICP for [company] covering: industry, revenue range, headcount,
tech stack, pain triggers, and buying committee. Output: ICP one-pager.

**7. Customer Journey Mapper**
Role: You are a Customer Experience Designer.
Task: Map the awareness → consideration → decision journey for [ICP]. Include emotional
state at each stage, key questions, and content that helps them move forward.

**8. Voice of Customer Synthesizer**
Role: You are a Market Researcher.
Task: From [input data], identify the top 3 jobs-to-be-done, top 3 frustrations, and
top 3 desired outcomes. Output: VoC summary card.

**9. Buyer Persona Validator**
Role: You are a Demand Generation Strategist.
Task: Test whether [persona] is specific enough to write targeted copy. Apply the
"could this describe half the internet?" filter. Sharpen until it passes.

**10. Customer Success Pattern Analyzer**
Role: You are a CRM Analyst.
Task: Identify the common patterns among [company's] top 20% of customers. What did
they have in common before buying? Output: ideal customer signal list.

### Messaging Architecture (Run for campaign messaging)

**11. Content Theme Generator**
Role: You are a Content Strategist.
Task: Generate 5 content themes for [company] that connect their expertise to their
ICP's pain points. Each theme should work across LinkedIn, email, and events.

**12. Messaging Hierarchy Builder**
Role: You are a B2B Copywriter.
Task: Build a messaging hierarchy: primary message → 3 supporting messages → proof points
for each. Ensure each layer addresses a different buyer persona or funnel stage.

**13. Brand Story Architect**
Role: You are a Narrative Strategist.
Task: Write [company's] brand story using the structure: World Before → The Tension →
The Insight → The Solution → The New World. Keep under 200 words.

**14. Content Audit & Strategy**
Role: You are a Content Marketing Strategist.
Task: Audit [company's] existing content against the ICP journey map. Identify gaps,
overlaps, and the 3 highest-priority pieces to create first.

**15. Competitive Voice Analysis**
Role: You are a Brand Analyst.
Task: Analyze the tone and messaging of [competitors]. What words appear most often?
What emotions do they target? Output: gap map showing what's unsaid.

### Campaign Concept (Run for new campaign launch)

**16. Market Category Definer**
Role: You are a Category Design Consultant.
Task: Is [company] competing in an existing category or creating a new one? If creating,
name the category and define it. If competing, identify the category leader and how to
steal positioning.

**17. Value Proposition Optimizer**
Role: You are a Conversion Rate Optimiser.
Task: Stress-test [company's] value proposition. Apply: "So what?", "Who cares?",
"Prove it" to each claim. Rewrite to survive all three challenges.

**18. Thought Leadership Positioner**
Role: You are a B2B Content Strategist.
Task: Define the one contrarian point of view [company] should own. What does everyone
in [industry] believe that [company] disputes — with evidence?

**19. Brand Archetype Identifier**
Role: You are a Brand Psychologist.
Task: Identify which of the 12 brand archetypes [company] embodies. Show how this
archetype should manifest in tone, visuals, and campaign concepts.

**20. Industry Disruptor Analysis**
Role: You are a Market Analyst.
Task: What is changing in [industry] in the next 12 months? What does this mean for
[ICP]? How should [company] position relative to this change?

**21. Campaign Concept Generator**
Role: You are a Creative Director with B2B campaign experience.
Task: Generate 3 campaign concepts for [topic/goal]. Each needs: name, central idea,
core message, hero content format, and why it will resonate with [ICP].

**22. Seasonal Strategy Developer**
Role: You are a Marketing Planner.
Task: Map [company's] campaign calendar to [ICP's] business calendar. When are they
planning budgets? Attending events? Hiring? Build campaign timing around their moments.

**23. Brand Activation Planner**
Role: You are an Integrated Marketing Manager.
Task: Turn [campaign concept] into a launch plan. Define the hero moment, supporting
content, internal alignment, and 90-day rollout sequence.

**24. Partnership Positioning**
Role: You are a Partner Marketing Strategist.
Task: Identify 3 non-competing brands [company] should co-create content with. Define
the shared audience, the co-marketing angle, and the format.

**25. Brand Evolution Roadmap**
Role: You are a Brand Consultant.
Task: Where is [company's] brand today vs. where it needs to be in 18 months? Define
the 3 milestones that signal brand evolution is working.

---

## Express Output Template

```
## 🟡 EXPRESS — Stage 1 Output

**Brand POV:** [One sentence — the contrarian belief they own]
**ICP Snapshot:** [Job title, company size, industry, top pain point]
**Campaign Concept:** [Name + central idea in 2 sentences]
**Style Guide Snapshot:** [3 tone adjectives + 2 vocabulary rules]
**Core Message:** [The one thing the audience should walk away knowing]
**Proof Points:** [3 specific, verifiable claims]
```
