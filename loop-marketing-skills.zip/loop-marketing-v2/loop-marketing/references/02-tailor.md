# Stage 2 — TAILOR Reference

## What Tailor Does
Personalise your campaign messaging for specific audience segments using CRM data, behavioural
signals, and lifecycle stage. Move from one brand message to many targeted conversations —
without losing brand consistency.

---

## The 25 Tailor Prompts (Embedded Engine)

### Data & Segmentation Foundation

**1. Customer Data Enrichment Strategist**
Role: You are a CRM Data Strategist.
Task: Identify the 5 most valuable data points [company] should be collecting in [HubSpot/Salesforce]
to enable meaningful personalisation. Include: how to collect, where to store, how to use.

**2. Intent Signal Identifier**
Role: You are a Demand Generation Analyst.
Task: Define the behavioural signals that indicate a contact in [CRM] is ready for the next
conversation. Map signals to CRM properties and lifecycle stages. Output: intent signal matrix.

**3. Behavioral Segmentation Builder**
Role: You are a Marketing Operations Specialist.
Task: Segment [audience] into 3-5 groups based on behaviour, not just demographics.
Use: engagement frequency, content consumed, stage in journey, pain point expressed.
Output: segment definitions with CRM filter logic.

**4. Customer Lifecycle Mapper**
Role: You are a Revenue Operations Strategist.
Task: Map the full customer lifecycle from Subscriber → Lead → MQL → SQL → Opportunity →
Customer → Advocate. Define the CRM trigger and marketing action at each transition.

**5. Predictive Scoring Model**
Role: You are a Lead Scoring Specialist.
Task: Build a lead scoring model for [company] using: fit score (ICP match) + engagement score
(behavioural signals). Define point values, threshold for MQL, and CRM implementation logic.

### Personalisation Design

**6. Hyper-Personalization Engine**
Role: You are a Marketing Personalisation Strategist.
Task: For each segment in [audience], define: personalised headline, personalised pain point
hook, personalised CTA, personalised social proof. Output: personalisation matrix.

**7. Dynamic Content Optimizer**
Role: You are a Marketing Automation Specialist.
Task: Identify 5 content blocks on [landing page/email] that should be dynamic. Define what
changes for each segment and the CRM property that triggers the change.

**8. Account-Based Personalization**
Role: You are an ABM Strategist.
Task: For [target account list], create company-level personalisation. Include: industry-specific
messaging, company-size adjustments, and known pain points from CRM activity.

**9. Persona-Based Journey Customizer**
Role: You are a Demand Generation Strategist.
Task: Map content and messaging variations for each buyer persona (e.g., COO vs CMO vs
Operations Director). What changes: the hook, the proof point, the CTA, the format.

**10. Contextual Messaging Framework**
Role: You are a B2B Copywriter.
Task: Create a contextual messaging guide — the same product/service described differently
based on: funnel stage (awareness/consideration/decision), role, and industry vertical.

### Email Personalisation

**11. Email Personalization Optimizer**
Role: You are an Email Marketing Specialist.
Task: Audit [email sequence] for personalisation opportunities. Beyond first name — add:
company name in context, role-specific pain point, industry benchmark, lifecycle-stage-aware CTA.

**12. Segmented Communication Strategy**
Role: You are a CRM Marketing Manager.
Task: Design the communication cadence for each lifecycle segment. Define: channel, frequency,
content type, and the one thing each segment needs to hear at their stage.

**13. Automated Personalization Sequences**
Role: You are a Marketing Automation Architect.
Task: Design 3 automated sequences triggered by behaviour (e.g., pricing page visit, demo
request, content download). Include: trigger, delay logic, message variations, exit conditions.

**14. Cross-Channel Message Synchronization**
Role: You are a Marketing Operations Manager.
Task: Ensure the message a contact receives on LinkedIn matches what they receive in email
and on retargeted ads. Design the synchronisation logic in [CRM/marketing automation platform].

**15. Lifecycle Email Personalisation**
Role: You are an Email Strategist.
Task: Write subject line and preview text variations for [email] for 3 different lifecycle stages:
new lead, engaged prospect, and re-engagement. Test which emotional trigger works at each stage.

### Conversion Personalisation

**16. Landing Page Personalizer**
Role: You are a Conversion Rate Optimiser.
Task: Create personalised landing page variants for [campaign] — one per key segment.
Change: headline, hero image concept, pain point framing, social proof type, CTA wording.

**17. Retargeting Personalisation Engine**
Role: You are a Paid Media Strategist.
Task: Design retargeting ad variations for contacts at each funnel stage. What message
is right for someone who visited pricing vs. someone who read a blog post vs. attended a webinar?

**18. Conversion Path Optimizer**
Role: You are a Demand Generation Manager.
Task: Map the optimal conversion path for each segment. Define the micro-conversions that
lead to the macro-conversion and the personalised nudges at each step.

**19. Social Proof Personaliser**
Role: You are a B2B Copywriter.
Task: Match social proof to audience. A fintech company needs a fintech case study.
A COO needs outcomes data, not feature lists. Map [company's] proof assets to [segments].

**20. Objection Handling Personaliser**
Role: You are a Sales Enablement Consultant.
Task: Identify the top 2 objections from each segment and write marketing content that
pre-handles them. Format: awareness-level content, not sales pitches.

### Retention & Expansion Personalisation

**21. Onboarding Experience Customizer**
Role: You are a Customer Success Strategist.
Task: Design personalised onboarding sequences for new customers segmented by: use case,
company size, and tech stack. What does success look like for each? What content helps them get there?

**22. Support Experience Personaliser**
Role: You are a Customer Experience Designer.
Task: Identify moments in the support journey where personalisation reduces churn.
Define CRM triggers and personalised communications for each at-risk signal.

**23. Renewal & Expansion Personaliser**
Role: You are a Customer Marketing Manager.
Task: Design personalised renewal and upsell campaigns based on: product usage data,
customer health score, and time to renewal. Output: trigger logic + message variants.

**24. Customer Journey Personalisation**
Role: You are a Revenue Operations Strategist.
Task: Map the full post-sale journey and identify where generic communications are losing
customers. Redesign those touchpoints with personalisation using [CRM] data.

**25. Feedback-Driven Personalisation**
Role: You are a Voice of Customer Analyst.
Task: Design a feedback collection system that automatically improves personalisation over
time. Include: what to ask, when, how to store in CRM, how to trigger messaging changes.

---

## Tailor Output Template

```
## 🔵 TAILOR — Stage 2 Output

**Segment 1: [Segment Name]**
- Who they are: [Job title, company size, stage]
- Their #1 pain: [Specific pain point]
- Personalised hook: [Opening line for this segment]
- Personalised CTA: [What you're asking them to do]
- CRM trigger: [The property/behaviour that activates this]

**Segment 2: [Segment Name]**
[Same structure]

**Segment 3: [Segment Name]**
[Same structure]

**Lead Scoring Logic:** [Fit score criteria + engagement score criteria + MQL threshold]
```
