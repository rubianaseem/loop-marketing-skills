# Stage 4 — EVOLVE Reference

## What Evolve Does
Turn campaign data into intelligence that makes the next loop smarter. Define what to measure,
what to test, and how to feed learning back into the system — so every loop compounds on the last.

---

## The 25 Evolve Prompts (Embedded Engine)

### Performance Analysis

**1. Campaign Performance Diagnostician**
Role: You are a Marketing Analytics Manager.
Task: Audit [campaign] performance against original KPIs. Diagnose what worked, what didn't,
and why. Separate symptoms (low CTR) from causes (wrong audience or wrong message). Output: diagnosis report.

**2. Real-Time Optimization Engine**
Role: You are a Performance Marketing Manager.
Task: Define the 3 metrics to watch in the first 48-72 hours of [campaign] launch. Set
thresholds: if [metric] drops below [X], take [specific action] immediately. Build a live monitoring protocol.

**3. Customer Journey Analytics Interpreter**
Role: You are a Marketing Analytics Specialist.
Task: Map where contacts are dropping off in [campaign] journey. Identify the highest-leverage
intervention point — the one fix that would move the needle most. Output: drop-off analysis + fix.

**4. Cohort Performance Analyzer**
Role: You are a Data Analyst.
Task: Compare performance across [campaign] audience cohorts: by segment, by channel, by
lifecycle stage, by geography. What do the top-performing cohorts have in common?

**5. Predictive Performance Modeler**
Role: You are a Marketing Scientist.
Task: Based on [week 1 data], forecast [campaign] performance over 30/60/90 days.
Define the leading indicators that predict final outcomes. Flag if trajectory requires intervention.

### Testing & Experimentation

**6. Systematic Testing Framework Designer**
Role: You are a Growth Marketing Manager.
Task: Design a 90-day testing calendar for [campaign/channel]. Prioritise tests by:
potential impact × ease of implementation. Include hypothesis, variable, success metric, and test duration.

**7. Multi-Variate Testing Strategist**
Role: You are a Conversion Rate Optimiser.
Task: Identify the 3 elements of [email/landing page/ad] with the highest impact on conversion.
Design a sequenced testing programme — test one variable at a time in priority order.

**8. Rapid Experimentation Engine**
Role: You are an Experimentation Specialist.
Task: Design a weekly experiment rhythm for [marketing team]. Define the template: hypothesis →
test design → success criteria → read time → decision rule. Goal: 4 experiments per month minimum.

**9. Sequential Testing Optimizer**
Role: You are a Marketing Scientist.
Task: For [campaign element], design a sequential test that builds on each result. Test 1
informs Test 2 which informs Test 3. Output: learning roadmap, not isolated tests.

**10. Marketing Mix Modeler**
Role: You are a Marketing Effectiveness Analyst.
Task: Evaluate the contribution of each channel to [campaign] outcomes. Recommend budget
reallocation based on actual performance data, not assumptions.

### ROI & Revenue Attribution

**11. ROI Optimization Calculator**
Role: You are a Marketing Finance Analyst.
Task: Calculate the true ROI of [campaign] including: content production cost, paid spend,
team time, and tool costs vs. revenue influenced. Present in CFO-ready format.

**12. Marketing Velocity Accelerator**
Role: You are a Revenue Operations Analyst.
Task: Measure the velocity of [campaign]: how fast contacts move through the funnel.
Identify the stage with the longest dwell time and design an intervention to accelerate it.

**13. Learning Integration Systematizer**
Role: You are a Marketing Operations Manager.
Task: Build a system that captures campaign learnings and makes them accessible for future
campaigns. Include: where to document, how to tag, who reviews, and how insights are actioned.

**14. Performance Forecasting Engine**
Role: You are a Demand Generation Director.
Task: Based on [historical data], forecast the pipeline and revenue impact of [campaign type]
for the next quarter. Build the model that becomes the basis for board-level planning.

**15. Marketing Agility Optimizer**
Role: You are a Marketing Operations Specialist.
Task: Identify the 3 biggest bottlenecks that slow down [marketing team's] ability to test
and iterate. Design process changes that double experimentation velocity without adding headcount.

### Cross-Channel Optimisation

**16. Cross-Channel Testing Coordinator**
Role: You are a Multi-Channel Marketing Manager.
Task: Design tests that span multiple channels simultaneously. Example: test message A on LinkedIn
+ email while message B runs on retargeting. Coordinate timing and audience exclusions to avoid contamination.

**17. Marketing Attribution Optimizer**
Role: You are a Marketing Analytics Specialist.
Task: Audit [company's] attribution model. Is first-touch, last-touch, or multi-touch right for
their sales cycle length? Redesign the model and rebuild in [CRM/analytics platform].

**18. Customer Lifetime Value Optimizer**
Role: You are a Customer Marketing Analyst.
Task: Identify which [campaign] tactics correlate with higher customer LTV — not just conversion.
Redesign the campaign to attract the customers most likely to expand and refer.

**19. Predictive Campaign Outcomes Before Launch**
Role: You are a Predictive Marketing Analyst.
Task: Before launching [campaign], predict performance ranges using: historical data from similar
campaigns, audience size estimates, benchmark CTR/CVR by channel. Output: probability-weighted forecast.

**20. Early Signal Monitoring & Live Optimisation**
Role: You are a Performance Marketing Manager.
Task: Define the early signals (first 24-72 hours) that predict [campaign] success or failure.
Build the decision tree: if [signal A] then [action A]; if [signal B] then [action B].

### Loop Feed-Forward

**21. Rapid Experimentation Framework Builder**
Role: You are a Growth Marketing Strategist.
Task: Build a repeatable framework for monthly experimentation across [marketing channels].
Output: experiment backlog template, prioritisation rubric, and monthly review rhythm.

**22. Competitive Velocity Analysis**
Role: You are a Competitive Intelligence Analyst.
Task: Monitor [competitors'] marketing velocity — how often they publish, launch campaigns,
test new formats. Compare to [company's] cadence. Identify where to accelerate.

**23. Multi-Loop Learning Synthesis**
Role: You are a Chief Marketing Officer.
Task: Synthesise learnings from [X previous campaigns] into strategic insights. What patterns
emerge? What hypotheses are now confirmed? What should be permanently changed in the marketing system?

**24. Customer Journey Drop-Off Diagnosis**
Role: You are a Customer Experience Analyst.
Task: Identify the exact moments in [customer journey] where contacts disengage. Diagnose
whether it's a message problem, channel problem, timing problem, or offer problem. Prioritise fixes.

**25. Continuous Optimisation Report Generator**
Role: You are a Marketing Reporting Specialist.
Task: Create a monthly marketing performance report template for [company] that: shows loop
velocity (experiments run), performance vs. benchmarks, top insight from the period, and one action item.

---

## Evolve Output Template

```
## 🟢 EVOLVE — Stage 4 Output

**Campaign KPIs:**
- Express KPIs: [Brand awareness metrics]
- Tailor KPIs: [Engagement and personalisation metrics]
- Amplify KPIs: [Reach, channel performance, pipeline influenced]
- Evolve KPIs: [Experiment velocity, attribution accuracy]

**3 Priority A/B Tests:**
1. Test: [What to test] | Hypothesis: [Why] | Success metric: [How to measure]
2. Test: [What to test] | Hypothesis: [Why] | Success metric: [How to measure]
3. Test: [What to test] | Hypothesis: [Why] | Success metric: [How to measure]

**Early Warning Signals (72-hour check):**
- If [metric] < [threshold] → [action]
- If [metric] > [threshold] → [scale action]

**Loop Velocity Target:** [X experiments per month]

## 🔁 Loop Feed-Forward

**What this loop taught us:**
[2-3 key learnings from this campaign]

**What changes in Loop 2:**
[Specific adjustments to ICP / messaging / channels / timing]

**The hypothesis for next loop:**
[One testable belief going into the next campaign]
```
