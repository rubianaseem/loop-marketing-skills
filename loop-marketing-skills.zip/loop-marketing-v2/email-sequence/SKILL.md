---
name: email-sequence
description: >
  Builds complete B2B email sequences — welcome series, nurture flows, re-engagement campaigns,
  post-event follow-ups, onboarding sequences, and sales handoff emails. ALWAYS trigger when
  a marketer needs to write a multi-email sequence, nurture flow, drip campaign, onboarding
  series, or any connected set of emails with a specific goal. Trigger for: "write an email
  sequence", "nurture flow", "welcome series", "drip campaign", "re-engagement emails",
  "post-webinar follow-up", "onboarding sequence", "outreach sequence", or "email automation".
  Produces ready-to-load email copy with subject lines, preview text, body copy, and CRM
  setup guidance.
---

# Email Sequence

## What This Skill Does

Produces complete, ready-to-use B2B email sequences — not just outlines, but the actual emails.
Each sequence is designed for a specific goal, audience, and lifecycle stage — with CRM
automation logic included.

---

## When To Use This Skill

- Post-webinar / post-event follow-up sequences
- Lead nurture flows for new MQLs
- Welcome series for new subscribers or trial users
- Re-engagement campaigns for cold or dormant contacts
- Onboarding sequences for new customers
- Post-purchase / expansion sequences
- Outreach sequences for SDR or BDR teams

---

## Input Required

1. **Sequence type** — which type from the list above?
2. **Audience** — who receives this? (Job title, lifecycle stage, pain point)
3. **Goal** — what conversion event are you driving toward?
4. **Brand voice** — tone, formality level, things they'd never say
5. **Key proof points** — results, testimonials, case studies available
6. **CRM platform** — HubSpot or Salesforce (affects automation notes)
7. **Sequence length** — 3, 5, or 7 emails? (recommend based on goal)

---

## Sequence Frameworks by Type

### Welcome Series (5 emails, Days 1/2/4/7/14)
- Email 1 (Day 1): Warm welcome + immediate value delivery + what to expect
- Email 2 (Day 2): Your biggest insight / the contrarian POV you hold
- Email 3 (Day 4): Social proof + case study or result
- Email 4 (Day 7): Education email — solve one problem relevant to ICP
- Email 5 (Day 14): Soft CTA — consultation, demo, download, or community

### Lead Nurture Flow (5 emails, Days 1/3/7/14/21)
- Email 1: Address the pain point that triggered the lead
- Email 2: Educate — how do others solve this problem?
- Email 3: Social proof — case study or data relevant to their situation
- Email 4: Handle the most common objection
- Email 5: Direct CTA — "Ready to talk?" or "Book a call"

### Re-Engagement (3 emails, 3-day cadence)
- Email 1: Acknowledge the silence, offer something new and valuable
- Email 2: Different angle — ask a question or share a provocative insight
- Email 3: Break-up email — low friction, honest, easy to reply to

### Post-Webinar / Post-Event (3 emails, Days 1/3/7)
- Email 1 (Day 1): Thank you + recording/resources + one key takeaway
- Email 2 (Day 3): Deeper dive on the most popular topic from the event
- Email 3 (Day 7): Soft CTA — what's the next step for interested attendees?

### Onboarding (5 emails, Days 1/3/7/14/30)
- Email 1: Welcome + the one thing to do first
- Email 2: Quick win — how to achieve value in the first week
- Email 3: Feature/capability they might not know about
- Email 4: Check-in — are they getting value? Proactive support offer
- Email 5: Milestone celebration + expansion/referral plant

---

## Email Output Format

For each email in the sequence, produce:

```
---
## Email [N] of [Total] — [Day/Timing]
**Goal:** [What this email needs to achieve]
**Trigger:** [CRM trigger or timing rule]

**Subject Line:** [Primary option]
**Subject Line Alt 1:** [Second option — different angle]
**Subject Line Alt 2:** [Third option — different angle]
**Preview Text:** [Extends subject, under 90 characters]

**Body:**
[Full email copy, ready to use]

**CTA:**
[Primary CTA text + what it links to]

**CRM Note:**
[HubSpot/Salesforce setup: enrollment trigger, delays, exit conditions]
---
```

---

## Key Principles

- **First email earns the second** — if email 1 doesn't deliver value, the rest won't be read
- **One goal per email** — multiple asks = no conversions
- **Subject line is the open rate** — test 2-3 options always
- **Short body > long body** — if they need to scroll far, you've lost them
- **Exit conditions matter** — contacts who convert should leave the sequence immediately
- **Personalisation beyond first name** — company, role, pain point, lifecycle stage

---

## Automation Notes

Always include for each sequence:
- **Enrollment trigger** — what event starts the sequence?
- **Exit conditions** — what stops it? (replies, conversions, status change)
- **Goal property** — what CRM property gets updated on conversion?
- **Suppression list** — who should never receive this sequence?
