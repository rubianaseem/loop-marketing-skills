---
name: competitor-analysis
description: >
  Produces a comprehensive B2B competitive intelligence analysis — covering positioning,
  messaging, content strategy, channel presence, pricing signals, and white space opportunities.
  ALWAYS trigger when a marketer wants to understand competitors, find positioning gaps, analyse
  competitor messaging, benchmark their content strategy, or identify how to differentiate.
  Trigger for: "analyse my competitors", "competitive analysis", "what are competitors saying",
  "how do we differentiate", "competitor messaging", "what's the white space", "who are we up
  against", "benchmark against competitors", or "competitive landscape." Also use when a new
  competitor enters the market or a campaign isn't winning against specific alternatives.
---

# Competitor Analysis

## What This Skill Does

Produces actionable competitive intelligence — not just a list of who the competitors are,
but what they're saying, where they're saying it, what they're NOT saying, and how to exploit
the gaps. Turns competitive awareness into marketing advantage.

---

## When To Use This Skill

- Before launching a new campaign or repositioning
- When a competitor launches a new product or campaign
- When win/loss analysis shows losing deals to a specific competitor
- To find the white space your brand can own
- When building the Express stage of a Loop Marketing campaign
- When a new marketing leader joins and needs competitive context
- Quarterly or bi-annual competitive review

---

## Input Required

1. **Your company/product** — what you do and who you serve
2. **Known competitors** — list what you know (even 2-3 names)
3. **Your ICP** — who you're both fighting to win
4. **What you already know** — any existing intel, wins, or losses vs. specific competitors
5. **Specific goal** — are you repositioning, building a campaign, or doing a quarterly review?

---

## Analysis Framework

### Layer 1 — Positioning & Messaging Analysis
For each competitor:
- What is their stated value proposition?
- What category do they place themselves in?
- What audience do they explicitly target?
- What tone do they use? (aspirational, technical, authoritative, friendly?)
- What do they lead with — price, quality, outcome, or methodology?

### Layer 2 — Content & Channel Intelligence
- Where are they most active? (LinkedIn, blog, YouTube, podcast, email)
- How frequently do they publish?
- What topics do they own?
- What formats dominate? (long-form, short-form, video, events)
- Who are their thought leaders?

### Layer 3 — White Space Mapping
- What topics in your space are NOBODY talking about?
- What customer pain points are unaddressed in competitor content?
- What proof types are competitors avoiding? (no case studies, no data, no pricing transparency)
- What channels are underserved?

### Layer 4 — Win/Loss Intelligence
- What objections does your sales team hear most when competing?
- What do customers say when they chose a competitor instead?
- What makes customers switch from a competitor to you?

---

## Output Document

```
# Competitive Analysis: [Your Company] vs. Market
**Date:** [Date] | **ICP:** [Target audience]

---

## Competitive Landscape Overview
[2-3 sentences: who the main players are and how the market is structured]

---

## Competitor Profiles

### Competitor 1: [Name]
**Positioning:** [Their stated value proposition in one sentence]
**Target audience:** [Who they explicitly target]
**Key messages:** [3 main claims they make]
**Tone:** [3 adjectives]
**Strengths:** [What they do well]
**Weaknesses:** [Where they're vulnerable]
**Content focus:** [Top 3 topics they publish about]
**Primary channels:** [Where they're most active]
**Pricing signals:** [Any public pricing or positioning signals]

### Competitor 2: [Name]
[Same structure]

### Competitor 3: [Name]
[Same structure]

---

## Messaging Gap Analysis
| Topic/Message | Competitor 1 | Competitor 2 | Competitor 3 | Gap? |
|---------------|-------------|-------------|-------------|------|
| [Topic] | ✅ Strong | ✅ Moderate | ❌ Absent | [Y/N] |
| [Topic] | ❌ Absent | ✅ Strong | ❌ Absent | [Y/N] |

---

## White Space Opportunities
**Conversations nobody is having:**
1. [Specific topic or angle — and why it matters to ICP]
2. [Specific topic or angle]
3. [Specific topic or angle]

**Proof types nobody is using:**
[e.g., "No competitor publishes ROI data or named case studies"]

**Channels nobody has claimed:**
[e.g., "Zero competitors running LinkedIn newsletters in this space"]

---

## Differentiation Recommendations
**Your strongest position:** [The one thing you can own that competitors can't easily match]
**Message to lead with:** [The specific claim that fills the biggest gap]
**Content to create first:** [The first piece that claims the white space]

---

## Competitive Battlecard (for Sales Team)
| When you hear... | They mean... | Your response... |
|-----------------|-------------|-----------------|
| "We're also talking to [Competitor]" | [What this signals] | [How to reframe] |
| "[Competitor] is cheaper" | [What this signals] | [How to respond] |
| "We tried [Competitor] before" | [What this signals] | [How to position] |
```

---

## Key Principles

- **Know what they're NOT saying as much as what they are** — the gaps are the opportunity
- **Analyse their content, not just their website** — positioning on paper vs. in practice differ
- **Win/loss data beats assumption** — build a habit of capturing this in the CRM
- **Competitive intelligence is a living document** — review quarterly minimum
- **Differentiation must be provable** — claims without proof are noise
