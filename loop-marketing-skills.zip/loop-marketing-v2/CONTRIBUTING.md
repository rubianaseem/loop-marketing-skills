# Contributing to Loop Marketing Skills

Thank you for wanting to improve this skill set. Here's how to contribute.

---

## Types of Contributions Welcome

- **New skills** — additional execution or strategy skills not yet covered
- **Skill improvements** — better prompts, clearer outputs, more precise triggers
- **Reference files** — additional context that makes existing skills more powerful
- **Bug fixes** — skills that aren't triggering correctly or producing poor outputs
- **Documentation** — clearer installation guides, better examples

---

## Skill Quality Standards

All skills must meet these standards to be merged:

### Required
- [ ] YAML frontmatter with `name` and `description`
- [ ] Description triggers confidently (passes the "would Claude actually use this?" test)
- [ ] Input requirements clearly stated
- [ ] Output format/template provided
- [ ] Key principles section
- [ ] Under 500 lines (move detail to references/ if longer)

### Recommended
- [ ] "Next stage" pointer — where does the marketer go after this skill?
- [ ] Example prompt that demonstrates the skill working
- [ ] Tested against at least 3 real use cases

---

## Skill Structure

```
skill-name/
├── SKILL.md               ← Required
└── references/            ← Optional, for large supporting content
    └── context.md
```

### SKILL.md Template

```markdown
---
name: skill-name
description: >
  [When to trigger — be pushy and specific. Include example phrases users would say.]
---

# Skill Name

## What This Skill Does
[2-3 sentences]

## When To Use This Skill
[Bullet list of scenarios]

## Input Required
[Numbered list]

## [Main Content / Framework / Process]
[The actual skill instructions]

## Output Format
[Template with clear structure]

## Key Principles
[3-5 strategic foundations]

## Next Step
[Where to go after this skill]
```

---

## How To Submit

1. Fork this repository
2. Create a branch: `feature/skill-name` or `fix/skill-name`
3. Add your skill following the standards above
4. Update `VERSIONS.md` with what you added/changed
5. Open a pull request with a clear description

---

## Ideas for New Skills

Skills we'd love to see:
- `hubspot-setup` — HubSpot portal audit and configuration guide
- `salesforce-sync` — HubSpot-Salesforce integration best practices
- `webinar-campaign` — Full webinar marketing campaign from pre to post
- `abm-campaign` — Account-based marketing campaign builder
- `demand-gen` — Paid demand generation strategy (LinkedIn Ads, Google)
- `revenue-reporting` — Marketing KPIs and board-ready reporting templates

---

## Questions?

Open an issue or connect on LinkedIn: [Rubia Naseem](https://www.linkedin.com/in/rubia-naseem/)
