# CLAUDE.md — Loop Marketing Skills

This repository contains 14 Claude AI skills built around HubSpot's Loop Marketing framework.

## Repository Structure

```
loop-marketing-skills/
├── README.md               ← Installation guide and overview
├── CLAUDE.md               ← This file
├── CONTRIBUTING.md         ← How to add or improve skills
├── VERSIONS.md             ← Changelog
│
├── loop-marketing/         ← Master orchestrator (start here)
│   ├── SKILL.md
│   └── references/
│       ├── 01-express.md   ← 25 Express prompts embedded
│       ├── 02-tailor.md    ← 25 Tailor prompts embedded
│       ├── 03-amplify.md   ← 25 Amplify prompts embedded
│       └── 04-evolve.md    ← 25 Evolve prompts embedded
│
├── express/                ← Stage 1 standalone skill
├── tailor/                 ← Stage 2 standalone skill
├── amplify/                ← Stage 3 standalone skill
├── evolve/                 ← Stage 4 standalone skill
│
├── campaign-brief/         ← Execution: campaign brief builder
├── content-remix/          ← Execution: content atomisation
├── copywriting/            ← Execution: B2B copy
├── email-sequence/         ← Execution: email sequences
├── icp-builder/            ← Strategy: ICP building
├── competitor-analysis/    ← Strategy: competitive intelligence
├── loop-scorecard/         ← Diagnostic: marketing health check
├── linkedin-content/       ← Distribution: LinkedIn content
└── aeo-optimiser/          ← Distribution: AI search optimisation
```

## For Claude Code Users

When working in this repository:
- Read the relevant SKILL.md before modifying any skill
- Keep SKILL.md files under 500 lines — move detail to references/ if needed
- Test skills by running example prompts listed in each SKILL.md
- Update VERSIONS.md when making changes

## Skill Writing Standards

All skills in this repo follow these standards:
1. YAML frontmatter with `name` and `description` fields
2. Description is "pushy" — explicit about when to trigger
3. Clear input requirements listed
4. Specific output format/template provided
5. Key principles section summarising the strategic foundations
6. "Next stage" or "next step" pointer at the end

## The 100 HubSpot Prompts

All 100 prompts from HubSpot's Loop Marketing framework are embedded in the master
`loop-marketing/references/` files. They serve as the invisible execution engine —
Claude fires them automatically, users never see them as a list.

Distribution: 25 in 01-express.md, 25 in 02-tailor.md, 25 in 03-amplify.md, 25 in 04-evolve.md.
