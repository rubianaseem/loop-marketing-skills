---
name: loop-scorecard
description: >
  Diagnoses the health of an existing B2B marketing programme using the Loop Marketing
  framework — scoring Express, Tailor, Amplify, and Evolve stages to identify the biggest
  gaps and highest-leverage improvements. ALWAYS trigger when a marketer wants to audit their
  current marketing, diagnose why a campaign isn't working, assess marketing maturity, review
  a CRM setup, or get a health check on their overall programme. Trigger for: "audit my
  marketing", "why isn't this working", "marketing health check", "score my campaigns",
  "loop scorecard", "what's wrong with our marketing", "diagnose our CRM", "marketing
  maturity assessment", or "review our marketing programme." Use before recommending fixes.
---

# Loop Scorecard

## What This Skill Does

Audits an existing B2B marketing programme against the 4 Loop Marketing stages — Express,
Tailor, Amplify, Evolve — and produces a scored health report with prioritised recommendations.
Turns "something isn't working" into a clear diagnosis and action plan.

---

## When To Use This Skill

- A new CMO or marketing hire doing a 90-day audit
- Before a campaign relaunch after underperformance
- When leadership asks "why isn't our marketing working?"
- Quarterly marketing review
- Before increasing marketing budget (audit before investing more)
- When sales and marketing are misaligned
- As a diagnostic tool before starting Loop Marketing work with a client

---

## Input Required

Ask the marketer to answer these diagnostic questions (or provide what's available):

**Express (Brand & Messaging):**
- Do you have a documented ICP? How specific is it?
- Do you have a defined brand POV / positioning statement?
- Do you have a style guide or messaging framework?
- What campaign concepts have you run in the past 12 months?

**Tailor (Personalisation & CRM):**
- Do you have audience segments defined in your CRM?
- Do you have lead scoring active? Is it being used by sales?
- Are you sending personalised emails beyond first name?
- Do you have lifecycle stages set up in HubSpot/Salesforce?

**Amplify (Distribution & Channels):**
- What channels are you currently using?
- How often do you publish content per channel?
- Do you have a content calendar?
- Are you repurposing content across formats?
- Do you have an AEO (AI search) strategy?

**Evolve (Measurement & Experimentation):**
- Do you have defined KPIs for marketing?
- Do you run A/B tests? How many per month?
- Do you have attribution set up in your CRM?
- Do you have a monthly marketing review process?
- What's your loop velocity (experiments per month)?

---

## Scoring System

Score each section 1-5:
- **1 — Not in place** — this doesn't exist at all
- **2 — Partially in place** — exists but inconsistent or unused
- **3 — In place but underperforming** — set up but not delivering value
- **4 — Working well** — functioning and delivering results
- **5 — Best in class** — exceeding benchmarks, compounding over time

---

## Scorecard Output

```
# Loop Marketing Scorecard: [Company Name]
**Date:** [Date] | **Assessed by:** [Name]

---

## Overall Loop Health: [X/20]

| Stage | Score | Status |
|-------|-------|--------|
| 🟡 Express (Brand & Messaging) | [X/5] | [🔴 Critical / 🟡 Needs Work / 🟢 Strong] |
| 🔵 Tailor (Personalisation & CRM) | [X/5] | [Status] |
| 🟣 Amplify (Distribution & Channels) | [X/5] | [Status] |
| 🟢 Evolve (Measurement & Experiments) | [X/5] | [Status] |

---

## Stage Diagnostics

### 🟡 EXPRESS — Score: [X/5]

**Strengths:**
- [What's working]

**Gaps:**
- [What's missing or weak]

**Priority fix:** [The single highest-leverage action]

---

### 🔵 TAILOR — Score: [X/5]

**Strengths:**
- [What's working]

**Gaps:**
- [What's missing or weak]

**Priority fix:** [The single highest-leverage action]

---

### 🟣 AMPLIFY — Score: [X/5]

**Strengths:**
- [What's working]

**Gaps:**
- [What's missing or weak]

**Priority fix:** [The single highest-leverage action]

---

### 🟢 EVOLVE — Score: [X/5]

**Strengths:**
- [What's working]

**Gaps:**
- [What's missing or weak]

**Priority fix:** [The single highest-leverage action]

---

## Top 3 Prioritised Recommendations

**1. [Highest priority — the root cause of most problems]**
Why: [Evidence from the audit]
Action: [Specific, executable next step]
Timeline: [1-2 weeks / 30 days / 90 days]
Expected impact: [What this fixes]

**2. [Second priority]**
[Same structure]

**3. [Third priority]**
[Same structure]

---

## Loop Velocity Benchmark
**Current:** [X experiments / month]
**Target:** [4+ experiments / month for healthy Loop Marketing]
**Gap:** [How far from benchmark]

---

## 90-Day Action Plan
[Month 1: Foundation fixes]
[Month 2: Build and test]
[Month 3: Optimise and scale]
```

---

## Key Principles

- **Diagnose before prescribing** — don't recommend fixes before understanding the root cause
- **The weakest stage limits the whole loop** — fix the floor, not the ceiling
- **Express problems look like Amplify problems** — bad messaging looks like bad distribution
- **Tailor problems look like pipeline problems** — poor personalisation kills conversion
- **Evolve problems compound over time** — no measurement means no learning, no growth
