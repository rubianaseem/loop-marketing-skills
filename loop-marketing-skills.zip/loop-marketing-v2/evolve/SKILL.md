---
name: evolve
description: >
  Run Stage 4 of HubSpot's Loop Marketing framework: Evolve. Defines measurement, experiments,
  and feed-forward learning so every campaign loop gets smarter. ALWAYS trigger when a marketer
  wants to measure campaign performance, set KPIs, run A/B tests, build attribution models,
  analyse what worked, improve ROI, or feed campaign learnings into the next iteration. Also
  trigger for: "how do I measure this", "what KPIs should I track", "A/B testing plan",
  "attribution model", "what's working", "campaign analysis", "improve performance", or
  "feed-forward". Use after Amplify stage or when analysing existing campaign data.
---

# EVOLVE — Stage 4: Measurement, Experiments & Feed-Forward

## What This Stage Does

Turns campaign data into intelligence. Defines what to measure, designs the experiments,
and creates the feed-forward system — so each loop compounds on the last. This is what
separates marketers who guess from marketers who know.

---

## When To Use Evolve Alone

- Setting KPIs before a campaign launches
- Designing an A/B testing programme
- Auditing attribution model accuracy
- Analysing why a campaign underperformed
- Building a monthly marketing reporting system
- Turning campaign learnings into strategy for the next quarter
- Designing a live optimisation protocol for a running campaign

---

## Input Required

1. **Campaign or channel to evolve** — what are you measuring/improving?
2. **Current performance data** — if available (or describe what's not working)
3. **CRM/analytics platform** — HubSpot, Salesforce, GA4?
4. **Business goal** — pipeline, revenue, brand, engagement?
5. **Team capacity** — how many experiments can they realistically run per month?

---

## Evolve Execution Flow

Read `references/evolve-prompts.md` for the full 25-prompt engine.

**For performance analysis:** Run prompts 1-5 (Performance Analysis set)
**For testing programme:** Run prompts 6-10 (Testing & Experimentation set)
**For ROI and attribution:** Run prompts 11-15 (ROI & Revenue Attribution set)
**For cross-channel optimisation:** Run prompts 16-20 (Cross-Channel set)
**For loop feed-forward:** Run prompts 21-25 (Feed-Forward set)

---

## Evolve Output

```
## 🟢 EVOLVE Output

**Campaign KPIs by Stage:**
- Express KPIs: [Brand/awareness metrics + targets]
- Tailor KPIs: [Engagement/personalisation metrics + targets]
- Amplify KPIs: [Reach/pipeline metrics + targets]
- Evolve KPIs: [Experiment velocity + attribution accuracy]

**3 Priority A/B Tests:**
1. [Variable] | Hypothesis: [Why it matters] | Metric: [How to measure]
2. [Variable] | Hypothesis: [Why it matters] | Metric: [How to measure]
3. [Variable] | Hypothesis: [Why it matters] | Metric: [How to measure]

**72-Hour Early Warning System:**
- If [metric] < [threshold] → [specific action]
- If [metric] > [threshold] → [scale action]

**Attribution Model:** [Which model + rationale + how to implement in CRM]

**Loop Velocity Target:** [X experiments per month]

## 🔁 Feed-Forward to Next Loop

**What this loop taught us:** [2-3 specific learnings]
**What changes in Loop 2:** [Specific adjustments]
**Hypothesis for next loop:** [One testable belief]
```

---

## Key Principles

- **Measure velocity, not just outcomes** — experiments run per month is a leading indicator
- **Attribution before amplification** — don't spend more until you know what's working
- **Feed-forward is the point** — learning that doesn't change behaviour is wasted
- **Simple models beat complex ones** — if the team won't use it, it doesn't matter
- **KPIs serve the business, not the marketer's ego** — tie everything to pipeline and revenue

---

## Next Loop

After Evolve → take feed-forward insights back into **EXPRESS** to start Loop 2.
The brand POV sharpens. The ICP becomes more precise. The campaign compounds.
