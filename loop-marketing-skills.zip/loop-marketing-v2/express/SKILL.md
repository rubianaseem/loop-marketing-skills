---
name: express
description: >
  Run Stage 1 of HubSpot's Loop Marketing framework: Express. Defines brand identity, ICP,
  point of view, and campaign concept. ALWAYS trigger when a marketer wants to define their
  brand positioning, build an ICP, develop a campaign concept, clarify their messaging,
  find their differentiation, or identify their target audience. Also trigger for: "who is
  my ideal customer", "what should my campaign be about", "how do I position this", "what
  makes us different", "write our brand story", or any request to establish the strategic
  foundation before creating content. Use this skill before any campaign creation begins.
---

# EXPRESS — Stage 1: Brand, ICP & Campaign Concept

## What This Stage Does

Establishes the strategic foundation for any campaign. Before content is created, distribution
planned, or budget spent — you need to know WHO you're talking to, WHAT you stand for,
and WHY anyone should care.

---

## When To Use Express Alone

- Starting a new campaign from scratch
- Repositioning a brand or product
- Launching into a new market or vertical
- Onboarding a new client and defining their marketing foundation
- Fixing campaigns that aren't converting (often a messaging problem)

---

## Input Required

1. **Company/brand** — what they do and who they serve
2. **Campaign goal** — what outcome are they driving?
3. **Available context** — any existing ICP, messaging, or competitor info
4. **Industry/vertical** — for competitive positioning

---

## Express Execution Flow

Read `references/express-prompts.md` for the full 25-prompt engine.

Select prompts based on what's needed:

**For brand positioning work:** Run prompts 1-5 (Brand Foundation set)
**For ICP definition:** Run prompts 6-10 (Audience Intelligence set)
**For messaging architecture:** Run prompts 11-15 (Messaging set)
**For campaign concept creation:** Run prompts 16-25 (Campaign Concept set)
**For a complete Express stage:** Run all relevant prompts in sequence

---

## Express Output

```
## 🟡 EXPRESS Output

**Brand POV:** [The one contrarian belief this brand owns]
**ICP Snapshot:** [Job title + company size + industry + top trigger pain]
**Differentiation:** [What competitors can't easily copy]
**Campaign Concept:** [Name + central idea + why it resonates with ICP]
**Core Message:** [The one thing the audience walks away knowing]
**Style Guide Snapshot:** [3 tone adjectives + 2 vocabulary rules]
**Proof Points:** [3 specific, verifiable claims]
```

---

## Key Principles

- **Start with the customer, not the product** — ICP pain drives everything
- **One clear POV** — trying to appeal to everyone appeals to no one
- **Differentiation must be defensible** — not just different, but better for a specific audience
- **The brand story beats the feature list** — always

---

## Next Stage

After Express → run **TAILOR** to personalise this foundation for audience segments.
Or use **Campaign Brief** skill to turn this into a structured brief before execution.
