# Express — 25 Prompts Reference

## Brand Foundation (Prompts 1-5)
Use for positioning, differentiation, and brand personality work.

**1. Brand Differentiation Analyzer**
Analyze [company] vs top 3 competitors. Find the one differentiator competitors cannot
easily copy. Output: positioning statement + 3 proof points.

**2. Competitor Gap Finder**
Map what competitors are NOT saying. Find the white space [company] can own.
Output: gap analysis + the conversation they should start.

**3. Customer Language Decoder**
From [reviews/testimonials], extract exact language customers use to describe their problem.
Output: 10 customer phrases to use verbatim in copy.

**4. Purpose & Mission Clarifier**
Distil [company's] purpose into one sentence that passes the "who cares?" test.
Output: purpose statement + the enemy they're fighting.

**5. Brand Personality Profiler**
Define brand personality using 3 adjectives + what they'd never say.
Output: personality card — tone, style, vocabulary dos and don'ts.

## Audience Intelligence (Prompts 6-10)
Use for ICP building and buyer persona development.

**6. Ideal Customer Profiler**
Build precise ICP: industry, revenue range, headcount, tech stack, pain triggers, buying committee.
Output: ICP one-pager.

**7. Customer Journey Mapper**
Map awareness → consideration → decision journey. Include emotional state, key questions,
content needed at each stage.

**8. Voice of Customer Synthesizer**
From input data, identify top 3 jobs-to-be-done, frustrations, and desired outcomes.
Output: VoC summary card.

**9. Buyer Persona Validator**
Test whether [persona] is specific enough to write targeted copy. Apply "could this describe
half the internet?" filter. Sharpen until it passes.

**10. Customer Success Pattern Analyzer**
Identify common patterns among top 20% of customers. What did they have in common before buying?
Output: ideal customer signal list.

## Messaging Architecture (Prompts 11-15)
Use for campaign messaging, content themes, and brand narrative.

**11. Content Theme Generator**
Generate 5 content themes connecting [company's] expertise to ICP pain points.
Each theme must work across LinkedIn, email, and events.

**12. Messaging Hierarchy Builder**
Build: primary message → 3 supporting messages → proof points for each.
Each layer addresses a different persona or funnel stage.

**13. Brand Story Architect**
Write brand story using: World Before → The Tension → The Insight → The Solution → The New World.
Under 200 words.

**14. Content Audit & Strategy**
Audit existing content against ICP journey map. Identify gaps and the 3 highest-priority
pieces to create first.

**15. Competitive Voice Analysis**
Analyze tone and messaging of [competitors]. What's unsaid? Output: gap map.

## Campaign Concept (Prompts 16-25)
Use for campaign ideation, positioning, and launch planning.

**16. Market Category Definer**
Is [company] competing in existing category or creating new one? Define the category or
show how to steal positioning from the leader.

**17. Value Proposition Optimizer**
Stress-test value proposition with "So what?", "Who cares?", "Prove it." Rewrite to survive all three.

**18. Thought Leadership Positioner**
Define the one contrarian POV [company] should own. What does everyone in [industry] believe
that [company] disputes — with evidence?

**19. Brand Archetype Identifier**
Identify which of 12 brand archetypes [company] embodies. Show how it manifests in tone,
visuals, and campaign concepts.

**20. Industry Disruptor Analysis**
What is changing in [industry] in next 12 months? How should [company] position relative
to this change?

**21. Campaign Concept Generator**
Generate 3 campaign concepts. Each needs: name, central idea, core message, hero format,
and why it resonates with ICP.

**22. Seasonal Strategy Developer**
Map campaign calendar to ICP's business calendar. When are they planning, hiring, attending
events? Time campaigns around their moments.

**23. Brand Activation Planner**
Turn [campaign concept] into a launch plan: hero moment, supporting content, internal alignment,
90-day rollout.

**24. Partnership Positioning**
Identify 3 non-competing brands for co-creation. Define shared audience, co-marketing angle,
and format.

**25. Brand Evolution Roadmap**
Where is the brand today vs. where it needs to be in 18 months? Define 3 milestones that
signal brand evolution is working.
