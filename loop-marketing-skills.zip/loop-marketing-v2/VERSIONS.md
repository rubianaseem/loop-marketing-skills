# Versions & Changelog

## v2.0.0 — February 2026

**Major release — 14-skill architecture**

### New Skills Added
- `express` — Standalone Stage 1 skill with full 25-prompt engine
- `tailor` — Standalone Stage 2 skill with full 25-prompt engine
- `amplify` — Standalone Stage 3 skill with full 25-prompt engine
- `evolve` — Standalone Stage 4 skill with full 25-prompt engine
- `campaign-brief` — Structured campaign brief builder
- `content-remix` — 16-format content atomisation engine
- `copywriting` — B2B copywriting frameworks for all formats
- `email-sequence` — Complete email sequence templates (5 types)
- `icp-builder` — Deep ICP document builder with fit scoring
- `competitor-analysis` — Competitive intelligence and gap mapping
- `loop-scorecard` — Marketing diagnostic and health scoring
- `linkedin-content` — 5 LinkedIn post formats + calendar framework
- `aeo-optimiser` — AI Engine Optimisation strategy and content

### Improvements to v1 Skills
- `loop-marketing` — Complete rewrite with stage-by-stage execution flow
- Reference files expanded: all 100 HubSpot prompts now embedded
- Output templates added to all stages
- Execution modes added (Quick Loop / Full Loop / Single Stage)

---

## v1.0.0 — January 2026

**Initial release — single master skill**

- `loop-marketing` — Master orchestrator with 4 reference files
- Basic Express, Tailor, Amplify, Evolve reference files
- README with Claude.ai installation instructions

---

*Built by [Rubia Naseem](https://www.linkedin.com/in/rubia-naseem/)*
