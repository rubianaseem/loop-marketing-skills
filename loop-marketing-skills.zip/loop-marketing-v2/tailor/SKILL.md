---
name: tailor
description: >
  Run Stage 2 of HubSpot's Loop Marketing framework: Tailor. Personalises campaign messaging
  for specific audience segments using CRM data, behavioural signals, and lifecycle stage.
  ALWAYS trigger when a marketer wants to segment their audience, personalise email or content,
  build lead scoring, set up CRM-triggered messaging, create lifecycle campaigns, or adapt
  one message for multiple personas. Also trigger for: "how do I personalise this", "segment
  my audience", "build lead scoring", "lifecycle campaign", "personalise my emails", "ABM
  messaging", or "CRM-triggered content." Use after the Express stage or when messaging
  foundation already exists.
---

# TAILOR — Stage 2: Audience Segmentation & Personalisation

## What This Stage Does

Takes your brand message and makes it specific. The same product. Different conversations.
Personalisation at scale using CRM data and behavioural triggers — not just mail merge.

---

## When To Use Tailor Alone

- Segmenting an existing audience before a campaign launch
- Building or auditing a lead scoring model
- Creating personalised email sequences per persona
- Setting up ABM (account-based marketing) messaging
- Designing lifecycle-triggered communications in HubSpot or Salesforce
- Adapting one campaign message for multiple job title personas

---

## Input Required

1. **Existing campaign concept or message** — what are you personalising?
2. **Audience data** — who are the key segments (personas, industries, lifecycle stages)?
3. **CRM platform** — HubSpot or Salesforce (affects trigger logic)
4. **Goal** — lead generation, nurture, expansion, or retention?

---

## Tailor Execution Flow

Read `references/tailor-prompts.md` for the full 25-prompt engine.

**For audience segmentation:** Run prompts 1-5 (Data & Segmentation set)
**For personalisation design:** Run prompts 6-10 (Personalisation Design set)
**For email personalisation:** Run prompts 11-15 (Email set)
**For conversion personalisation:** Run prompts 16-20 (Conversion set)
**For retention/expansion:** Run prompts 21-25 (Retention set)

---

## Tailor Output

```
## 🔵 TAILOR Output

**Segment 1: [Name]**
- Profile: [Job title, company size, lifecycle stage]
- #1 Pain: [Specific, not generic]
- Personalised hook: [Opening line written for them]
- Personalised CTA: [Specific next step]
- CRM trigger: [Property or behaviour that activates this]

**Segment 2: [Name]** [Same structure]
**Segment 3: [Name]** [Same structure]

**Lead Scoring Model:**
- Fit score criteria: [ICP match signals + point values]
- Engagement score criteria: [Behavioural signals + point values]
- MQL threshold: [Score that triggers sales handoff]

**Automation Sequences:**
- Trigger 1: [Behaviour] → [Sequence name + steps]
- Trigger 2: [Behaviour] → [Sequence name + steps]
```

---

## Key Principles

- **Segment by behaviour, not just demographics** — what they do matters more than who they are
- **CRM is the personalisation engine** — if it's not in the CRM, it can't be personalised
- **Lead scoring must be used** — a score that nobody acts on is decorative data
- **Personalisation fails without data hygiene** — clean CRM data first

---

## Next Stage

After Tailor → run **AMPLIFY** to distribute personalised messages across channels.
Or use **Email Sequence** skill to write the actual sequence copy.
