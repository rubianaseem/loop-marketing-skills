---
name: icp-builder
description: >
  Builds a detailed, actionable Ideal Customer Profile (ICP) for B2B companies — going deep
  on firmographics, technographics, behavioural signals, buying committee, and pain triggers.
  ALWAYS trigger when a marketer or founder wants to define, refine, or pressure-test their
  ICP, understand their best customers, build buyer personas, identify their target market,
  or understand who they should and shouldn't sell to. Trigger for: "build my ICP", "who is
  my ideal customer", "define my target market", "buyer persona", "who should we target",
  "our ICP is too broad", "help me narrow down our audience", or "what makes a good fit
  customer for us." Also trigger when campaigns are underperforming due to audience mismatch.
---

# ICP Builder

## What This Skill Does

Builds a precise, evidence-based Ideal Customer Profile that marketing, sales, and operations
can actually use. Not a vague persona poster — a working document that drives targeting,
messaging, lead scoring, and campaign decisions.

---

## When To Use This Skill

- Starting a new company or entering a new market
- Realising the current ICP is too broad ("we work with anyone")
- Campaigns not converting because the audience is wrong
- Sales and marketing disagree on what a good lead looks like
- Preparing for a Series A/B where investors need ICP clarity
- Building lead scoring that needs ICP fit signals
- New CMO or marketing hire needs to understand the ideal customer

---

## Input Required

1. **Current best customers** — who are your happiest, highest-value clients? (even just 3-5 examples)
2. **What they bought** — which product/service, at what price point?
3. **Why they chose you** — if known, what made them pick you over alternatives?
4. **Industries served** — any vertical concentration in successful customers?
5. **Company size** — employee count, revenue range of best customers
6. **Geography** — UK, Europe, North America, or global?
7. **Tech stack** — what CRM, tools, or platforms do they use?
8. **Pain triggers** — what event or situation caused them to seek help?

If the marketer is early-stage and has limited customer data, apply the hypothesis-first ICP method.

---

## ICP Building Framework

### Step 1 — Customer Pattern Analysis
Identify patterns across best customers:
- What industries appear most frequently?
- What company sizes show up?
- What job titles were involved in the buying decision?
- What CRM or tech platforms do they use?
- What event triggered the purchase?

### Step 2 — Fit Scoring Criteria
Define what makes a GOOD fit vs. BAD fit customer:

**Positive signals (include):**
- Industry match
- Revenue/headcount in target range
- CRM platform match
- Pain trigger present
- Budget authority accessible

**Negative signals (exclude):**
- Industries with long procurement cycles
- Company sizes too small for ROI
- Tech stacks incompatible with the solution
- Decision-makers not reachable

### Step 3 — Buying Committee Mapping
Who is involved in the purchase decision?
- **Champion** — who advocates internally?
- **Economic Buyer** — who approves budget?
- **End User** — who uses the solution daily?
- **Blocker** — who might oppose the purchase?

---

## ICP Output Document

```
# Ideal Customer Profile: [Company Name]
**Version:** [Date]

---

## Tier 1 — Primary ICP (80% of pipeline focus)

### Company Profile
- **Industry:** [Specific verticals]
- **Revenue Range:** [X to Y]
- **Headcount:** [X to Y employees]
- **Geography:** [Countries/regions]
- **CRM Platform:** [HubSpot / Salesforce / Other]
- **Tech Stack Signals:** [Tools that indicate fit]

### Buying Triggers
[The specific events or situations that cause them to seek this solution]
1. [Trigger 1 — e.g., "New CRO hired and inherited broken CRM"]
2. [Trigger 2 — e.g., "Board demanding pipeline visibility before Series B"]
3. [Trigger 3 — e.g., "Sales team threatening to abandon CRM entirely"]

### Buying Committee
| Role | Title | Pain | Motivator | Objection |
|------|-------|------|-----------|-----------|
| Champion | [Title] | [Pain] | [Motivator] | [Objection] |
| Economic Buyer | [Title] | [Pain] | [Motivator] | [Objection] |
| End User | [Title] | [Pain] | [Motivator] | [Objection] |

### Pain Points
1. [Specific, acute pain — not generic]
2. [Specific, acute pain]
3. [Specific, acute pain]

### Desired Outcomes
1. [What they want to achieve — in their language]
2. [What they want to achieve]
3. [What they want to achieve]

### Disqualifiers (who NOT to pursue)
- [Company type / signal that indicates bad fit]
- [Company type / signal]

---

## Tier 2 — Secondary ICP (20% of pipeline focus)
[Repeat structure for secondary segment if applicable]

---

## ICP Fit Scoring (for CRM Lead Scoring)
| Signal | Points | CRM Property |
|--------|--------|--------------|
| [Industry match] | +[X] | [Property name] |
| [Revenue range] | +[X] | [Property name] |
| [Trigger event] | +[X] | [Property name] |
| [Disqualifier] | -[X] | [Property name] |

**MQL Threshold:** [Score that qualifies a contact for sales]

---

## Messaging Implications
**What they care about most:** [The #1 pain to lead with in all campaigns]
**The language they use:** [3-5 phrases from voice of customer research]
**What they don't want to hear:** [Jargon or positioning that turns them off]
```

---

## Key Principles

- **Your ICP is your best customers — not who you wish you had**
- **Specific beats broad** — "B2B SaaS companies in fintech with 50-200 employees using HubSpot" beats "B2B tech companies"
- **Triggers matter as much as firmographics** — same company, different timing, different fit
- **The buying committee is not one person** — map all stakeholders
- **Bad fit is as important as good fit** — know who to disqualify early
