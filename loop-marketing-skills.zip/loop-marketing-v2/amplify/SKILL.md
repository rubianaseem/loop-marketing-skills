---
name: amplify
description: >
  Run Stage 3 of HubSpot's Loop Marketing framework: Amplify. Builds the multi-channel
  distribution plan including AI engine optimisation (AEO). ALWAYS trigger when a marketer
  wants to distribute a campaign, build a content calendar, plan channels, repurpose content,
  optimise for AI search, plan paid media, identify co-marketing partners, or maximise reach
  from one piece of content. Also trigger for: "where should I post this", "content calendar",
  "content repurposing", "channel strategy", "AEO", "AI search optimisation", "LinkedIn strategy",
  "paid distribution", or "amplify this content." Use after Express and Tailor stages.
---

# AMPLIFY — Stage 3: Multi-Channel Distribution & Content Engine

## What This Stage Does

Takes your personalised campaign and distributes it everywhere your audience actually is.
One idea → ten formats → thirty days of content. Plus AI engine optimisation so your brand
appears when buyers ask ChatGPT, Claude, or Perplexity for solutions.

---

## When To Use Amplify Alone

- Building a content calendar from an existing campaign concept
- Atomising a piece of hero content into multiple formats
- Planning channel mix for a new campaign
- Setting up AEO (AI Engine Optimisation) strategy
- Designing a paid amplification plan
- Identifying co-marketing or partnership opportunities
- Maximising reach from a webinar, event, or report

---

## Input Required

1. **Campaign concept or hero content** — what are you distributing?
2. **Target audience** — who are you reaching?
3. **Available channels** — LinkedIn, email, paid, events, community?
4. **Budget level** — organic only, small paid, or full paid support?
5. **Timeline** — 30-day sprint or 90-day campaign?

---

## Amplify Execution Flow

Read `references/amplify-prompts.md` for the full 25-prompt engine.

**For channel strategy:** Run prompts 1-7 (Channel Strategy set)
**For content production plan:** Run prompts 8-15 (Content Production set)
**For digital distribution:** Run prompts 16-20 (Digital Distribution set)
**For events and community:** Run prompts 21-25 (Events & Community set)

---

## Amplify Output

```
## 🟣 AMPLIFY Output

**Channel Mix:**
Primary: [Channel + rationale]
Secondary: [Channel + rationale]
Experimental: [Channel + rationale]

**Hero Content:** [Format + working title]

**Content Atomisation (from one hero piece):**
1. [LinkedIn long-form post — topic]
2. [LinkedIn carousel — angle]
3. [Email newsletter section — hook]
4. [Short video script concept]
5. [Podcast talking points]
6. [Slide deck outline]
7. [Twitter/X thread hook]
8. [Blog post angle]

**30-Day Calendar:**
Week 1: [Content + channel + day]
Week 2: [Content + channel + day]
Week 3: [Content + channel + day]
Week 4: [Content + channel + day]

**AEO Strategy:**
Questions to own: [3 questions ICP asks AI tools]
Content format: [Structure that earns AI citation]

**Co-Marketing Opportunity:** [Partner + angle + format]
```

---

## Key Principles

- **One idea, many formats** — production efficiency comes from atomisation
- **Channel-native first** — adapt format and tone to each platform, don't just cross-post
- **AEO is the new SEO** — your audience is asking AI tools for recommendations
- **Organic reach compounds** — consistency beats volume
- **Distribution is a skill** — great content with poor distribution fails

---

## Next Stage

After Amplify → run **EVOLVE** to define measurement, experiments, and the next loop.
Or use **LinkedIn Content** skill to write the actual posts for your campaign.
