---
name: aeo-optimiser
description: >
  Optimises B2B content and brand presence for AI Engine Optimisation (AEO) — so the brand
  appears when buyers ask ChatGPT, Claude, Perplexity, or Google AI Overviews for solutions,
  recommendations, or expertise. ALWAYS trigger when a marketer wants to be found in AI search,
  optimise for ChatGPT or Perplexity, build AEO strategy, understand AI search, make their
  content AI-visible, or future-proof their SEO. Trigger for: "AEO", "AI search", "optimise
  for ChatGPT", "appear in AI answers", "Perplexity optimisation", "AI engine optimisation",
  "generative engine optimisation", "GEO", "how do I get found in AI search", or "my buyers
  are using AI instead of Google." This is the skill for the post-SEO era of B2B marketing.
---

# AEO Optimiser

## What This Skill Does

Positions a B2B brand to be cited, recommended, and surfaced by AI engines — ChatGPT,
Claude, Perplexity, Google AI Overviews, and others — when the ICP asks questions about
their industry, problems, and solutions. AEO is the new SEO. This skill builds the strategy
and produces the content to win it.

---

## When To Use This Skill

- B2B buyers in your ICP are increasingly using AI tools for research
- Existing SEO content isn't ranking or driving enough traffic
- Building a thought leadership strategy that extends beyond Google
- Wanting to be cited as the authoritative source in your niche
- Amplifying a campaign with AI-visible content
- Adding AEO to the Amplify stage of a Loop Marketing campaign
- Future-proofing content strategy for the AI search era

---

## Input Required

1. **Company/brand** — what do they do and who do they serve?
2. **ICP** — who is searching for their expertise?
3. **Existing content** — what have they already published?
4. **Target topics** — what questions or topics do they want to own?
5. **Primary platform** — where will AEO-optimised content live? (blog, LinkedIn, website)

---

## AEO vs SEO — Key Differences

| Traditional SEO | AEO (AI Engine Optimisation) |
|-----------------|------------------------------|
| Optimise for keywords | Optimise for questions |
| Rank in a list of 10 | BE the answer |
| Page 1 result | Cited source in AI response |
| Backlinks matter | Citations and authority matter |
| Metadata and technical | Content clarity and structure |
| One answer per page | One answer per question |

---

## AEO Strategy Framework

### Step 1 — Question Mining
Identify the questions your ICP asks AI tools. These are:
- "What is the best [solution] for [problem]?"
- "How do I [achieve outcome] without [common objection]?"
- "What are the differences between [option A] and [option B]?"
- "Who are the best [experts/companies] for [specific need]?"
- "What should I look for when choosing [solution]?"

For each topic area, generate 10-15 specific questions the ICP would type into ChatGPT or Perplexity.

### Step 2 — Content Structure for AI Citability
AI engines cite content that is:
- **Direct:** Answers the question in the first 1-2 sentences
- **Structured:** Uses clear headings, numbered lists, Q&A format
- **Authoritative:** Contains specific data, named examples, expert perspective
- **Complete:** Covers the topic comprehensively in one place
- **Credible:** On an established domain with genuine expertise signals

### Step 3 — Content Formats That Earn AI Citations
1. **Definitive guides** — "The Complete Guide to [Topic]" — comprehensive, well-structured
2. **FAQ pages** — Q&A format maps directly to how AI engines search for answers
3. **Comparison pages** — "HubSpot vs Salesforce for [use case]" — AI loves structured comparisons
4. **Statistics pages** — Original data or curated industry statistics with citations
5. **Definition pages** — "What is [term]? A B2B Guide" — AI cites definitional content heavily
6. **Case studies** — Specific, named, quantified results that AI tools use as proof

### Step 4 — Brand Citation Building
To be cited by AI engines, you need to be referenced across the web:
- **PR and media coverage** — industry publications, podcasts, webinars
- **LinkedIn visibility** — AI tools increasingly surface LinkedIn content
- **Guest content** — articles and contributions on authoritative industry sites
- **Community presence** — being mentioned in Slack communities, forums, Reddit
- **Partner mentions** — co-marketing with established brands builds citation authority

---

## AEO Content Template

For each target question, produce:

```
**Question:** [The exact question the ICP would ask an AI tool]
**AI Answer Target:** [The 2-3 sentence answer you want AI to cite — clear, direct, authoritative]
**Supporting Content:** [The full-length piece that earns the citation]

---
Title: [Optimised for the question]
Meta/Opening paragraph: [Answers the question directly in first 2 sentences]

[Structured content with clear H2 headings]
[Each section answers a related sub-question]
[Include: specific data, named examples, expert quotes]
[Include: FAQ section at the bottom with 5-8 related questions]
[Include: structured summary/conclusion]

Internal links: [Related content to build topical authority]
Schema markup recommendation: [FAQ schema / How-to schema / Article schema]
```

---

## AEO Audit — Rate Existing Content

Score each piece of content 1-5 on:
- **Question alignment** — does it directly answer a question the ICP asks?
- **Direct answer** — does it answer in the first paragraph?
- **Structure** — clear headings, lists, Q&A format?
- **Authority signals** — data, named sources, expert perspective?
- **Completeness** — would an AI tool trust this as a definitive source?

**Priority for optimisation:** Lowest-scoring, highest-traffic-potential pages first.

---

## 30-Day AEO Quickstart Plan

Week 1: Question mining — identify top 20 questions the ICP asks AI tools
Week 2: Audit existing content — score against AEO criteria, identify top 5 to optimise
Week 3: Create 2 new AEO-optimised pieces targeting highest-value questions
Week 4: Begin citation building — pitch to 3 industry publications, update LinkedIn profile

---

## Key Principles

- **Be the answer, not a result** — AEO is about being cited, not ranked
- **Questions are the new keywords** — write for how people talk to AI, not how they type into Google
- **Structure earns citations** — AI tools prefer content they can easily parse and attribute
- **Authority is still the foundation** — years of quality content and genuine expertise can't be faked
- **AEO and SEO are complementary** — AEO-optimised content also performs better in traditional search
- **Speed matters** — be the first authoritative source on emerging topics in your niche
