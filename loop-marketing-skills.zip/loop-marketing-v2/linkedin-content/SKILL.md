---
name: linkedin-content
description: >
  Creates high-performing B2B LinkedIn content — posts, carousels, newsletters, and thought
  leadership pieces — using Loop Marketing principles and platform-native best practices.
  ALWAYS trigger when a marketer wants to write LinkedIn posts, create a LinkedIn content
  strategy, build a LinkedIn content calendar, write a thought leadership piece, create a
  LinkedIn carousel, or improve their LinkedIn presence. Trigger for: "write a LinkedIn post",
  "LinkedIn content", "LinkedIn strategy", "thought leadership post", "LinkedIn carousel",
  "what should I post on LinkedIn", "LinkedIn content calendar", "help me with LinkedIn",
  or any request to create B2B social content. Applies research-backed LinkedIn copywriting
  to produce posts that stop the scroll, build authority, and drive business outcomes.
---

# LinkedIn Content

## What This Skill Does

Creates B2B LinkedIn content that builds authority, grows audience, and drives pipeline — not
just likes. Every post is built on a strategic angle, written in a platform-native format, and
designed to serve a specific business goal.

---

## When To Use This Skill

- Writing individual high-impact posts on any B2B topic
- Building a monthly LinkedIn content calendar
- Creating a thought leadership series for a founder or marketing leader
- Writing carousels that teach and convert
- Developing a LinkedIn newsletter strategy
- Turning campaign content into LinkedIn-native posts
- Amplifying a webinar, report, or case study on LinkedIn

---

## Input Required

1. **Topic or idea** — what is the post or content about?
2. **Author's voice** — who is writing? What's their tone and experience?
3. **Target audience** — who should this reach on LinkedIn?
4. **Goal** — awareness, lead gen, connection requests, newsletter subs, or brand building?
5. **Format** — single post, carousel, newsletter, or series?
6. **Key insight or data** — the one thing that makes this worth posting

---

## LinkedIn Content Formats

### Format 1 — The Insight Post (800-1200 words)
Best for: Teaching, building authority, demonstrating expertise
Structure:
- **Hook (Line 1):** The one line that earns the click to expand. Specific, surprising, or provocative.
- **Setup (Lines 2-4):** Context that makes the hook make sense
- **Story or observation:** Real experience or data that makes the insight tangible
- **The lesson:** What this means for the reader — specific and actionable
- **CTA:** Soft — ask a question, invite comments, or mention a resource

### Format 2 — The List Post (Short-form)
Best for: Reach, saves, shares
Structure:
- **Hook:** "X things [job title] needs to stop doing" or "X signs your [system] is broken"
- **List items:** Each item is 1-2 sentences, specific, not generic
- **Closing line:** The meta-insight that ties the list together
- **CTA:** Question or resource

### Format 3 — The Carousel (8-10 slides)
Best for: Education, saves, high engagement
Structure:
- Slide 1: Hook slide — compelling promise ("How I did X in Y days")
- Slides 2-8: One insight per slide, large text, minimal design
- Slide 9: Summary / key takeaway
- Slide 10: CTA slide — follow, newsletter, consultation, or download

Write: Title for each slide + 2-3 sentence content per slide + CTA slide copy

### Format 4 — The Story Post (Personal experience)
Best for: Trust building, emotional connection, viral potential
Structure:
- **The moment:** Drop into a specific scene — time, place, emotion
- **The tension:** What was at stake? What was hard?
- **The turn:** The insight or decision that changed things
- **The lesson:** What does this mean for the reader?
- **The invitation:** Question or soft CTA

### Format 5 — The Contrarian Post
Best for: Thought leadership, debate, reach
Structure:
- **The claim:** State the conventional wisdom, then dispute it (boldly)
- **The evidence:** Specific data, experience, or observation that supports your position
- **The implication:** What should the reader do differently?
- **The invitation:** "Agree or disagree? Tell me below."

---

## LinkedIn Hook Formulas

Use these for Line 1 of any post:

- "Most [job titles] [do X wrong]. Here's why."
- "After [X years / X clients / X campaigns], here's what I've learned about [topic]."
- "Nobody talks about [uncomfortable truth]. But they should."
- "I made a [mistake] that cost [X]. What I learned:"
- "[Specific result] in [timeframe]. Here's the exact [framework/process]."
- "Stop [common behaviour]. Do [this] instead."
- "[Controversial claim]. Unpopular opinion:"
- "The question I get asked most: [question]. Here's my real answer."

---

## Content Calendar Framework (Monthly)

Week 1: **Authority post** — deep expertise, long-form insight
Week 2: **Engagement post** — poll, question, or contrarian take
Week 3: **Social proof post** — case study, client story, or result
Week 4: **Community post** — share someone else's work + your perspective

Frequency recommendation: 3-4 posts per week for serious LinkedIn growth

---

## Post Output Format

```
---
**FORMAT:** [Post type]
**GOAL:** [Awareness / Lead gen / Authority / Engagement]
**TARGET AUDIENCE:** [Job title / ICP]

**POST:**

[Full LinkedIn post, ready to copy-paste]

---

**Engagement hooks (optional):**
- [Question variation 1 to add at the end]
- [Question variation 2]

**Best posting time:** [Tuesday-Thursday, 7-9am or 12-1pm in their timezone]
**Hashtags:** [3-5 relevant hashtags]
```

---

## Key Principles

- **Line 1 is everything** — it's the only line shown before "see more"
- **Write for mobile first** — short paragraphs, plenty of white space, easy to skim
- **One idea per post** — multiple insights dilute reach and saves
- **Specificity beats generality** — "42% of B2B marketers" beats "many marketers"
- **Comments beat likes** — write posts that invite debate and genuine response
- **Consistency compounds** — showing up every week beats viral posts once a quarter
- **AEO starts on LinkedIn** — content that AI tools cite starts as clear, quotable insights on LinkedIn
